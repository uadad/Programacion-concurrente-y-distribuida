#!/bin/bash

fuente="$1.pfc"
listfile="$1.lst"
objfile="$1.obj"
pmdfile="$1.pmd"

if [ ! -f $fuente ]
then
	echo '*****************************'
	echo '.'
	echo El fichero $fuente NO existe
	echo '.'
	echo '*****************************'
else
	if [ -f $objfile ]
	then 
		rm $objfile
	fi
	if [ -f $listile ]
	then 
		rm $listfile
	fi
	if [ -f $pmdfile ]
	then
		rm $pmdfile
	fi
	./pfccomp $fuente $listfile $objfile
	if [ ! -f $objfile ]
	then
		echo '*****************************'
		echo '.' 
		echo errores de compilacion en $fuente
		echo consulte $listfile
		echo '.'
		echo '*****************************'
	else
		echo '========================================================================'
		echo '                                   EJECUCION'
		echo '========================================================================'
		./pint $objfile $pmdfile

		if [ -f $objfile ]
		then 
			rm $objfile
		fi
		if [ -f $listile ]
		then 
			rm $listfile
		fi
		if [ -f $pmdfile ]
		then
			rm $pmdfile
		fi

	fi
fi


