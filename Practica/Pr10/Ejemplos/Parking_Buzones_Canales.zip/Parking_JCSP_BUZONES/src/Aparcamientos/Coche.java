/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aparcamientos;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jcsp.lang.AltingChannelInput;
import org.jcsp.lang.SharedChannelOutput;

/**
 *
 * @author pedro
 */
public class Coche implements Runnable {

    int id;

    Random rnd = new Random();
    CanvasParking cv;
    private SharedChannelOutput entracoche, salecoche;
    private AltingChannelInput permiso;

    public Coche(int id, CanvasParking cv, SharedChannelOutput entracoche, SharedChannelOutput salecoche, AltingChannelInput permiso) {
        this.id = id;
        this.cv = cv;
        this.entracoche = entracoche;
        this.salecoche = salecoche;
        this.permiso = permiso;
    }

    @Override
    public void run() {
        try {

            System.out.println("Soy el coche " + id);
            cv.inserta(1, id);
            Thread.sleep(200);
            entracoche.write(id);
            char donde = (char) permiso.read();
            cv.quita(1, id);
            cv.aparcacoche(id, donde);
            System.out.println("Coche --->" + id + " Aparcado");
            Thread.sleep((rnd.nextInt(5) + 3) * 1000);
            cv.salecoche(id, donde);
            Thread.sleep(200);
            salecoche.write(donde);
            System.out.println("<--- Coche " + id + " se marcha");

        } catch (InterruptedException ex) {
            Logger.getLogger(Bus.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
