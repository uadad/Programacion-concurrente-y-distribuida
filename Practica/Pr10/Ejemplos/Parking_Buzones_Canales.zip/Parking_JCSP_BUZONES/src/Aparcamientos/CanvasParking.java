/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aparcamientos;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * Se usa para representar el problema del parking de los coches y autobuses
 *
 * @author pedro
 */
public class CanvasParking extends Canvas {

    Image cochesimg1, cochesimg2, busimg2, busimg1, puentegif, barcoimg;
    List colacoche = new LinkedList();
    List colabus = new LinkedList();
    List cochesparking = new ArrayList<Integer>(3);
    List tipoparkingbus = new ArrayList<Integer>(2); //0 BUS, 1 COCHE
    List busesparking = new ArrayList<Integer>(2);

    int tipo = 0;
    MediaTracker dibu;

    /**
     *
     * @param ancho es el ancho del canvas
     * @param alto es el alto del canvas
     */
    public CanvasParking(int ancho, int alto) {
        this.setSize(ancho, alto);
        this.setBackground(Color.white);

        cochesimg1 = Toolkit.getDefaultToolkit().getImage(getClass().getResource("image/cochec1.gif"));
        cochesimg2 = Toolkit.getDefaultToolkit().getImage(getClass().getResource("image/cochec2.gif"));
        busimg1 = Toolkit.getDefaultToolkit().getImage(getClass().getResource("image/bus1.png"));
        busimg2 = Toolkit.getDefaultToolkit().getImage(getClass().getResource("image/bus2.png"));

        dibu = new MediaTracker(this);
        try {
            dibu.addImage(cochesimg1, 1);
            dibu.waitForID(1);
            dibu.addImage(cochesimg2, 2);
            dibu.waitForID(2);
            dibu.addImage(busimg1, 3);
            dibu.waitForID(3);
            dibu.addImage(busimg2, 4);
            dibu.waitForID(4);

        } catch (java.lang.InterruptedException e) {
            System.out.println("Couldn't load one of the images");
        }

        for (int i = 0; i < 3; i++) {
            cochesparking.add(i, -1);
        }
        for (int i = 0; i < 2; i++) {
            tipoparkingbus.add(i, -1);
            busesparking.add(i, -1);
        }
    }

    /**
     * Inserta un vehiculo en la cola y lo visualiza
     *
     * @param donde es la cola en la que se inserta 1=cola de coches 2=cola del
     * bus
     * @param id es el identificador del vehículo que se inserta
     */
    public synchronized void inserta(int donde, int id) {
        if (donde == 1) {
            colacoche.add(id);
        } else {
            colabus.add(id);
        }
        this.repaint();
    }

    /**
     * Elimina y borra un vehíuclo de la cola
     *
     * @param donde es la cola en la que se inserta 1=cola de coches 2=cola del
     * bus
     * @param id es el identificador del vehículo que se inserta
     */
    public synchronized void quita(int donde, int id) {

        if (donde == 1) {
            colacoche.remove((Object) id);
        } else {
            colabus.remove((Object) id);
        }
        this.repaint();
    }

    /**
     * Visualiza un autobus aparcado en el parking de autouses
     *
     * @param id es el identificador del bus aparcado
     */
    public synchronized void aparcabus(int id) {
        int pos = busesparking.indexOf(-1);
        busesparking.set(pos, id);
        tipoparkingbus.set(pos, 0); // 0 BUS;  1 COCHE

        this.repaint();
    }

    /**
     * Borra el bus que está aparcado en el parking de autobuses
     */
    public synchronized void salebus(int id) {
        int pos = busesparking.indexOf(id);

        busesparking.set(pos, -1);
        tipoparkingbus.set(pos, -1); // 0 BUS;  1 COCHE

        this.repaint();
    }

    /**
     * Visualiza un coche aparcado en alguno de los huecos del parking
     *
     * @param id es el identificador del coche que se va a visualizar aparcado
     * @param donde es el parking en el que aparca 'C'=parking de coches
     * 'B'=parking de buses
     */
    public synchronized void aparcacoche(int id, char donde) {
        try {
            if (donde == 'C') {
                int pos = cochesparking.indexOf(-1);
                cochesparking.set(pos, id);
            }
            if (donde == 'B') {
                int pos = busesparking.indexOf(-1);
                busesparking.set(pos, id);
                tipoparkingbus.set(pos, 1); // 0 BUS;  1 COCHE
            }

        } catch (Exception e) {
            System.out.println("No hay sitio para " + id + " ... " + e.getMessage());
        }

        this.repaint();
    }

    /**
     * Borra un coche del parking en el que está aparcado
     *
     * @param id es el identificador del coche que se va a borrar
     * @param donde es el parking del que se borra: 'C'=parking de coches
     * 'B'=parking de buses
     */
    public synchronized void salecoche(int id, char donde) {
        if (donde == 'C') {
            cochesparking.set(cochesparking.indexOf(id), -1);
        }
        if (donde == 'B') {
            int pos = busesparking.indexOf(id);
            busesparking.set(pos, -1);
            tipoparkingbus.set(pos, -1);

        }

        this.repaint();
    }

    /**
     * Metodo update del canvas, invocado por repaint()
     *
     * @param g
     */
    @Override
    public void update(Graphics g) {

        paint(g);

    }

    /**
     * Método paint del canvas, incovado por update
     *
     * @param g
     */
    @Override
    public synchronized void paint(Graphics g) {
        BufferedImage imagen = new BufferedImage(getWidth(), getHeight(), ColorModel.OPAQUE);
        Graphics gbuf = imagen.getGraphics();
        gbuf.setColor(Color.green);
        gbuf.fillRect(0, 0, getWidth(), getHeight());

        gbuf.setColor(Color.white);
        gbuf.fillRect(92, 70, getWidth(), 80);
        gbuf.fillRect(92, 180, getWidth(), 80);
        gbuf.fillRect(90, 10, 40, 270);

        gbuf.setColor(Color.CYAN);
        for (int i = 0; i < 3; i++) {
            gbuf.fillRect(10, 80 * i + 10, 80, 70);

        }
        gbuf.setColor(Color.PINK);
        gbuf.fillRect(10, 270, 250, 70);

        gbuf.setColor(Color.black);

        Iterator iter = colacoche.iterator();
        int i = 0;
        while (iter.hasNext()) {
            gbuf.drawString("   " + iter.next() + "   ", 100 + 50 * i, 100);
            gbuf.drawImage(cochesimg1, 100 + 50 * i, 100, null);
            i++;
        }

        iter = colabus.iterator();
        i = 0;
        while (iter.hasNext()) {
            gbuf.drawString("   " + iter.next() + "   ", 170 + 110 * i, 200);
            gbuf.drawImage(busimg1, 170 + 110 * i, 200, null);
            i++;

        }

        for (int j = 0; j < 3; j++) {
            if ((int) cochesparking.get(j) != -1) {
                gbuf.drawString("   " + cochesparking.get(j) + "   ", 20, 80 * j + 25);
                gbuf.drawImage(cochesimg1, 20, 80 * j + 25, null);
            }
        }

       
        if ((int) busesparking.get(0) != -1) {
            gbuf.drawString("   " + busesparking.get(0) + "   ", 15, 285);
            if ((int) tipoparkingbus.get(0) != 1) {
                gbuf.drawImage(busimg1, 15, 285, null);
            } else {
                gbuf.drawImage(cochesimg1, 15, 285, null);
            }

        }
        if ((int) busesparking.get(1) != -1) {
            gbuf.drawString("   " + busesparking.get(1) + "   ", 125, 285);
            if ((int) tipoparkingbus.get(1) != 1) {
                gbuf.drawImage(busimg2, 135, 285, null);
            } else {
                gbuf.drawImage(cochesimg2, 135, 285, null);
            }
            
        }

        g.drawImage(imagen, 0, 0, this);

    }
}
