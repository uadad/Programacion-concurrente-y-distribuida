/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Aparcamientos;

import org.jcsp.lang.Alternative;
import org.jcsp.lang.Any2OneChannel;
import org.jcsp.lang.Guard;
import org.jcsp.lang.One2OneChannel;

/**
 *
 * @author pedro
 */
public class Controlador extends Thread {

    private int librecoche = 3, librebus = 2;
    private Any2OneChannel entracoche, entrabus, salecoche, salebus;
    private One2OneChannel[] permiso;

    Controlador(Any2OneChannel entracoche, Any2OneChannel entrabus, Any2OneChannel salecoche, Any2OneChannel salebus, One2OneChannel[] permiso) {
        this.entrabus = entrabus;
        this.entracoche = entracoche;
        this.salebus = salebus;
        this.salecoche = salecoche;
        this.permiso = permiso;
    }

    @Override
    public void run() {

        boolean[] precondition = new boolean[4];
        Guard[] or = new Guard[4];
        or[0] = entracoche.in();
        or[1] = entrabus.in();
        or[2] = salecoche.in();
        or[3] = salebus.in();
        Alternative selector = new Alternative(or);

        while (true) {
            precondition[0] = librecoche > 0 || (librebus > 0 && !entrabus.in().pending());
            precondition[1] = librebus > 0;
            precondition[2] = true;
            precondition[3] = true;
            int index = selector.select(precondition);
            switch (index) {
                case 0:
                    int idc = (int) entracoche.in().read();
                    char donde;
                    if (librecoche > 0) {
                        librecoche--;
                        donde = 'C';
                    } else {
                        librebus--;
                        donde = 'B';
                    }
                    System.out.println("                Dando permiso al coche "+idc+ " en "+donde);
                    permiso[idc].out().write(donde);
                    break;

                case 1:
                    int idb = (int) entrabus.in().read();
                    librebus--;
                    permiso[idb].out().write('B');
                    break;

                case 2:
                    char lugar = (char) salecoche.in().read();
                    if (lugar == 'C') {
                        librecoche++;
                    } else {
                        librebus++;
                    }
                    break;
                case 3:
                    salebus.in().read();
                    librebus++;
                    break;

                default:
                    System.out.println("Error de select");
            }

        }
    }
}
