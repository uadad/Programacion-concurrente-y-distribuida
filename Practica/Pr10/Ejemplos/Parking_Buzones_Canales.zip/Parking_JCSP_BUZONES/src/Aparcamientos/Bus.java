/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aparcamientos;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jcsp.lang.AltingChannelInput;
import org.jcsp.lang.SharedChannelOutput;

/**
 *
 * @author pedro
 */
public class Bus extends Thread {

    int id;

    Random rnd = new Random();
    CanvasParking cv;
    private SharedChannelOutput entrabus, salebus;
    private AltingChannelInput permiso;

    public Bus(int id, CanvasParking cv, SharedChannelOutput entrabus, SharedChannelOutput salebus, AltingChannelInput permiso) {
        this.id = id;
        this.cv = cv;
        this.entrabus = entrabus;
        this.salebus = salebus;
        this.permiso = permiso;
    }

    @Override
    public void run() {
        try {

            System.out.println("Soy el bus " + id);
            cv.inserta(2, id);
            Thread.sleep(200);
            entrabus.write(id);
            permiso.read();
            cv.quita(2, id);
            cv.aparcabus(id);
            System.out.println("------------------------->  Bus " + id + " Aparcado");
            Thread.sleep((rnd.nextInt(3) + 4) * 1000);
            cv.salebus(id);
            Thread.sleep(200);

            salebus.write(id);
            System.out.println("<<------------------------  Bus " + id + " se marcha");

        } catch (InterruptedException ex) {
            Logger.getLogger(Bus.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
